/*Escrever um algoritmo que lê uma matriz M(12,13) e divida todos os 13 elementos de
 c *ada uma das 12 linhas de M pelo maior elemento em módulo daquela linha. Escrever
 a matriz lida e a modificada*/

#include <stdio.h>
#include <stdlib.h>
int main()
{
    int M[12][13];
    int maiorvlr = 0;
    for(int i = 0; i < 12; i++)
    {
        for(int j = 0; j < 13; j++)
        {
            M[i][j] = rand() % 10;
            printf("[%d] ", M[i][j]);
        }
        printf("\n");
    }
        //percorrendo e lendo a matriz
        for(int i = 0; i < 12; i++)
        {
            for(int j = 0; j < 13; j++)
            {
                if(M[i][j] > maiorvlr)
                {
                    maiorvlr = M[i][j];
                }
            }
            printf("%d\n", maiorvlr);
            maiorvlr = 0;
        }
        printf("\n");

    return (0);
}
