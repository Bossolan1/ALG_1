#include <stdio.h>
#include <stdlib.h>
/*
int main()
{
    int matheus[10], control = 1;
    for(int i = 0; i < 10; i++)
    {
        printf("%d\n",control);
        matheus[i] = control;
        control++;
    }

    for(int i =0; i <= 9; i++)
    {
        for(int j = i + 1; j <= 9; j++)
        {
            if(matheus[i] > matheus[j])
            {
                control = matheus[i];
                matheus[i] = matheus[j];
                matheus[j] = control;
            }
        }
    }
    printf("---------------------------------\n");
    for(int i = 0; i < 10; i++)
    {
        printf("%d\n", matheus[i]);
    }
    return(0);
}
*/

int main()
{
  int vec[10], control, i = 0, j = 0;

  for(i = 0; i < 10; i++)
    {
        scanf("%d", &vec[i]);
    }

    for (i = 0; i <= 9; i++)
    {
        for (j = 0; j <= 9; j++);
        {
            if ( vec[j] > vec[j+1])
                {
                   control = vec[j];
                   vec[j] = vec[j+1];
                   vec[j+1] = control;
                   i-=2*(i!=0);



                }
        }
    }
    for (j = 0; j <= 9; j++)
    {
        printf("%d ", vec[j]);
    }
    return(0);
}
