#include<stdio.h>

  int main()
  {
    printf("Bem-vindos ao / Mundo \ da progracao em \" C \" !!!\n");
    return(0);
  }
